package model;

/**
 * Created by Enock on 8/30/2016.
 */
public class LeaveDetails {
    private  String Entitlement,BroughtForward,LeaveEarne,LeaveTaken,LeaveForfeited,LeaveBalance,EnYrBalance,Description;

    public LeaveDetails(String Entitlement,String BroughtForward,String LeaveEarne,String LeaveTaken,String LeaveForfeited,String LeaveBalance,String EnYrBalance,String Description)
    {
        this.Entitlement=Entitlement;
        this.BroughtForward=BroughtForward;
        this.LeaveEarne=LeaveEarne;
        this.LeaveTaken=LeaveTaken;
        this.LeaveForfeited=LeaveForfeited;
        this.LeaveBalance=LeaveBalance;
        this.EnYrBalance=EnYrBalance;
        this.Description=Description;
    }

    public String getEntitlement() {
        return Entitlement;
    }

    public void setEntitlement(String Entitlement) {
        this.Entitlement = Entitlement;
    }

    public String getBroughtForward() {
        return BroughtForward;
    }

    public void setBroughtForward(String BroughtForward) {
        this.BroughtForward = BroughtForward;
    }

    public void setLeaveEarne(String LeaveEarne) {
        this.LeaveEarne = LeaveEarne;
    }

    public String getLeaveEarne() {
        return LeaveEarne;
    }

    public void setLeaveTaken(String LeaveTaken) {
        this.LeaveTaken = LeaveTaken;
    }

    public String getLeaveTaken() {
        return LeaveTaken;
    }

    public void setLeaveForfeited(String LeaveForfeited) {
        this.LeaveForfeited = LeaveForfeited;
    }

    public String getLeaveForfeited() {
        return LeaveForfeited;
    }

    public void setLeaveBalance(String LeaveBalance) {
        this.LeaveBalance = LeaveBalance;
    }

    public String getLeaveBalance() {
        return LeaveBalance;
    }

    public void setEnYrBalance(String EnYrBalance) {
        this.EnYrBalance = EnYrBalance;
    }

    public String getEnYrBalance() {
        return EnYrBalance;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getDescription() {
        return Description;
    }

}
