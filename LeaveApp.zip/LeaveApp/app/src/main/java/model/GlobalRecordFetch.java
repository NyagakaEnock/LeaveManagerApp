package model;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v7.app.AlertDialog;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.enock.retrofit.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import activity.Profile;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;


/**
 * Created by Enock on 8/10/2016.
 */
public class GlobalRecordFetch {
    private Context context;
    //public static final String ROOT_URL = "http://192.168.42.164:8012/LeaveMobile";
    public static final String ROOT_URL = "http://192.168.1.157:8012/LeaveMobile";
    public GlobalRecordFetch(Context c) {
        context = c;
    }

    public void MyalertDialog(String msg)
    {
        AlertDialog.Builder builder =  new AlertDialog.Builder(context, R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Response")
                .setMessage(msg)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.ok, null).show();
    }


}
