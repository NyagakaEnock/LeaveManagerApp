package model;

/**
 * Created by Enock on 9/6/2016.
 */
public class Recalls {
    private  String FullName,Leave,Expected;

    public Recalls(String FullName,String Leave,String Expected)
    {
        this.FullName=FullName;
        this.Leave=Leave;
        this.Expected=Expected;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public String getLeave() {
        return Leave;
    }

    public void setLeave(String Leave) {
        this.Leave = Leave;
    }

    public String getExpected() {
        return Expected;
    }

    public void setExpected(String Expected) {
        this.Expected = Expected;
    }
}
