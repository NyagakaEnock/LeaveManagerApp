package model;

/**
 * Created by Enock on 8/17/2016.
 */
public class RowFetch {


    private String Name;
    private String Value;

    public RowFetch(String Name,String Value){

        this.Name = Name;
        this.Value = Value;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    public String getValue() {
        return Value;
    }

    public void setValue(String Value) {
        this.Value = Value;
    }
}