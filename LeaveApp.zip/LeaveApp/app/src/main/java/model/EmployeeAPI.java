package model;

import java.util.Map;

import retrofit.client.Response;
import retrofit.http.Field;
import retrofit.http.FormUrlEncoded;
import retrofit.http.GET;
import retrofit.Callback;
import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;
import retrofit.http.PartMap;
import retrofit.mime.TypedFile;

/**
 * Created by Enock on 8/10/2016.
 */
public interface EmployeeAPI {

    @FormUrlEncoded
    @POST("/Employee/GlobalRecordCheck")
    public void GlobalRecordFetch(
            @Field("table") String table,
            @Field("value") String value,
            @Field("field") String field,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/Login")
    public void Login(
            @Field("txtUsername") String username,
            @Field("txtPassWord") String password,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/RegisterGCMID")
    public void updateGCMUniqueId(
            @Field("UniqueId") String UniqueId,
            @Field("StaffIDNO") String StaffIDNO,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/DeleteNotifications")
    public void DeleteNotifications(
            @Field("ID") String ID,
            Callback<Response> callback);
    @FormUrlEncoded
    @POST("/Home/RefreshNotifications")
    public void refreshNotifications(
            @Field("StaffIDNO") String ID,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/GetCurrentLeaveInfo")
    public void GetCurrentLeaveInfo(
            @Field("StaffIDNO") String StaffId,
            @Field("Leave") String Leave,
            Callback<Response> callback);
    @FormUrlEncoded
    @POST("/Home/ChangePass")
    public void ChangePass(
            @Field("Current") String Current,
            @Field("Confirm") String Confirm,
            @Field("StaffIDNO") String StaffIDNO,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/Refresh")
    public void Refresh(
            @Field("StaffIDNO") String StaffIDNO,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/NewApplication")
    public void NewApplication(
            @Field("StaffIDNO") String StaffId,
            @Field("Leave") String Leave,
            @Field("strStartdate") String strStartdate,
            @Field("strLastDate") String strLastDate,
            @Field("strDateExpected") String strDateExpected,
            @Field("txtDaysApplied") String txtDaysApplied,
            @Field("LeaveBFwd") String LeaveBFwd,
            @Field("LeaveBFwd") String chkRequireLeaveAllowance,
            @Field("txtComments") String txtComments,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/Home/FirstApproval")
    public void FirstApproval(
            @Field("txtStaffIDNo") String StaffId,
            @Field("txtLeaveType") String Leave,
            @Field("ApprovedStartDate") String strStartdate,
            @Field("txtApprovedLastDate") String strLastDate,
            @Field("txtDateExpected") String strDateExpected,
            @Field("chkReject") String chkReject,
            @Field("txtDaysApplied") String txtDaysApplied,
            @Field("GetCurrentStaffID") String GetCurrentStaffID,
            @Field("txtComments") String txtComments,
            @Field("txtAppNumber") String txtAppNumber,
            Callback<Response> callback);
    @FormUrlEncoded
    @POST("/Home/SecondApproval")
    public void SecondApproval(
            @Field("txtStaffIDNo") String StaffId,
            @Field("txtLeaveType") String Leave,
            @Field("ApprovedStartDate") String strStartdate,
            @Field("txtApprovedLastDate") String strLastDate,
            @Field("txtDateExpected") String strDateExpected,
            @Field("chkReject") String chkReject,
            @Field("txtDaysApplied") String txtDaysApplied,
            @Field("GetCurrentStaffID") String GetCurrentStaffID,
            @Field("txtComments") String txtComments,
            @Field("txtAppNumber") String txtAppNumber,
            Callback<Response> callback);
    @FormUrlEncoded
    @POST("/Home/FinalApproval")
    public void FinalApproval(
            @Field("txtStaffIDNo") String StaffId,
            @Field("txtLeaveType") String Leave,
            @Field("ApprovedStartDate") String strStartdate,
            @Field("txtApprovedLastDate") String strLastDate,
            @Field("txtDateExpected") String strDateExpected,
            @Field("chkReject") String chkReject,
            @Field("txtDaysApplied") String txtDaysApplied,
            @Field("GetCurrentStaffID") String GetCurrentStaffID,
            @Field("txtComments") String txtComments,
            @Field("txtAppNumber") String txtAppNumber,
            Callback<Response> callback);

    @Multipart
    @POST("/Home/UploadProfilePic")
    void UploadFile(@Part("file")TypedFile file, @Part("StaffIDNO")String StaffIDNO, Callback<Response> callback);
}
