package model;

/**
 * Created by Enock on 8/12/2016.
 */
public class Employee {
    public  String EmployeeNo;
    public Employee(String EmployeeNo){
        this.EmployeeNo = EmployeeNo+"ENOCK";
    }
}
