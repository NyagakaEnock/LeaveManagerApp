package model;

/**
 * Created by Enock on 8/22/2016.
 */
public class LeaveSummary {
    private  String DateApplied,Entitlement,BeforeApplication,Status,StartDate,EndDate,ReturnDate,LeaveDesc,ApplicationNo,DaysApplied;
    public  LeaveSummary(String DateApplied,String Entitlement,String BeforeApplication,String Status,String StartDate,String EndDate,String ReturnDate,String LeaveDesc,String ApplicationNo,String DaysApplied)
    {
        this.DateApplied=DateApplied;
        this.Entitlement=Entitlement;
        this.BeforeApplication=BeforeApplication;
        this.Status=Status;
        this.StartDate=StartDate;
        this.EndDate=EndDate;
        this.ReturnDate=ReturnDate;
        this.LeaveDesc=LeaveDesc;
        this.ApplicationNo = ApplicationNo;
        this.DaysApplied = DaysApplied;
    }
    public String getDateApplied() {
        return DateApplied;
    }

    public void setDateApplied(String DateApplied) {
        this.DateApplied = DateApplied;
    }
    public String getLeaveDesc() {
        return LeaveDesc;
    }

    public void setLeaveDesc(String LeaveDesc) {
        this.LeaveDesc = LeaveDesc;
    }
    public String getEntitlement() {
        return Entitlement;
    }

    public void setEntitlement(String Entitlement) {
        this.Entitlement = Entitlement;
    }

    public String getBeforeApplication() {
        return BeforeApplication;
    }

    public void setBeforeApplication(String BeforeApplication) {
        this.BeforeApplication = BeforeApplication;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String StartDate) {
        this.StartDate = StartDate;
    }
    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String EndDate) {
        this.EndDate = EndDate;
    }
    public String getReturnDate() {
        return ReturnDate;
    }

    public void setReturnDate(String ReturnDate) {
        this.ReturnDate = ReturnDate;
    }

    public String getApplicationNo() {
        return ApplicationNo;
    }

    public void setApplicationNo(String ApplicationNo) {
        this.ApplicationNo = ApplicationNo;
    }

    public String getDaysApplied() {
        return DaysApplied;
    }

    public void setDaysApplied(String DaysApplied) {
        this.DaysApplied = DaysApplied;
    }

}
