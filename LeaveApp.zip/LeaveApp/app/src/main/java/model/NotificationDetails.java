package model;

import org.json.JSONObject;

/**
 * Created by Enock on 9/15/2016.
 */
public class NotificationDetails {
    private  String Subject,Message,DateSent;
    private JSONObject JsonObject;
    public NotificationDetails(String Subject,String Message,String DateSent,JSONObject JsonObject)
    {
        this.DateSent=DateSent;
        this.Subject=Subject;
        this.Message=Message;
        this.JsonObject=JsonObject;

    }
    public String getSubject() {
        return Subject;
    }

    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

    public String getDateSent() {
        return DateSent;
    }

    public void setDateSent(String DateSent) {
        this.DateSent = DateSent;
    }

    public JSONObject getJsonObject() {
        return JsonObject;
    }

    public void setJsonObject(JSONObject JsonObject) {
        this.JsonObject = JsonObject;
    }

}
