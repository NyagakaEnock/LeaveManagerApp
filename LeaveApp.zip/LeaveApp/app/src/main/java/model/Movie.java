package model;

import org.json.JSONObject;

/**
 * Created by Enock on 8/13/2016.
 */
public class Movie {
    private String title, genre, year,dates;
private JSONObject jsonObject;
    public Movie() {
    }

    public Movie(String title, String genre, String year,String dates,JSONObject jsonObject) {
        this.title = title;
        this.genre = genre;
        this.year = year;
        this.dates = dates;
        this.jsonObject = jsonObject;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String name) {
        this.title = name;
    }
    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.title = dates;
    }
    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }
}
