package model;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by Enock on 9/22/2016.
 */
public class RefreshApp extends AsyncTask<String, Void, String> {
    private Context context;
    public RefreshApp(Context context)
    {
       this.context = context;
    }
    @Override
    public String doInBackground(String... params) {
        String StaffIDNO = params[0];
        Reload(StaffIDNO);
        return  StaffIDNO;

    }

    @Override
    public void onPostExecute(String result) {

    }

    @Override
    public void onPreExecute() {}

    @Override
    public void onProgressUpdate(Void... values) {}



    public void Reload(final String StaffId) {

        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(context);
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.Refresh(
                StaffId,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            SharedPreferences.Editor editor = context.getSharedPreferences("MySessions", 0).edit();
                            editor.clear();
                            SharedPreferences.Editor editor2 = context.getSharedPreferences("MySessions", 0).edit();
                            editor2.putString("jsonResponce",output);
                            editor2.commit();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void failure(RetrofitError error) {

                        Toast.makeText(context, "Connection Failed. Please Try Again.",Toast.LENGTH_LONG).show();
                    }
                }
        );


    }
}
