package adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.enock.retrofit.R;
import java.util.List;
import model.LeaveDetails;
import model.Recalls;
/**
 * Created by Enock on 9/6/2016.
 */
public class RecallsAdapter extends RecyclerView.Adapter<RecallsAdapter.MyViewHolder>  {
    private List<Recalls> recallsList;
    public RecallsAdapter(List<Recalls> recallsList) {
        this.recallsList = recallsList;
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView FullName,Leave,Expected;
        public MyViewHolder(View view) {
            super(view);
            FullName = (TextView) view.findViewById(R.id.RecallsemplyeeName);
            Leave = (TextView) view.findViewById(R.id.RecallsLeaveType);
            Expected = (TextView) view.findViewById(R.id.RecallsExpected);
        }
    }
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Recalls recalls = recallsList.get(position);
        holder.FullName.setText(recalls.getFullName());
        holder.Leave.setText(recalls.getLeave());
        holder.Expected.setText(recalls.getExpected());
    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recalls_recyclerview, parent, false);
        return new MyViewHolder(itemView);
    }
    @Override
    public int getItemCount() {
        return recallsList.size();
    }
}
