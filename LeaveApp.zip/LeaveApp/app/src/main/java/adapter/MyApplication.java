package adapter;

import android.app.Application;

import com.firebase.client.Firebase;

/**
 * Created by Enock on 8/18/2016.
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //Initializing firebase
        Firebase.setAndroidContext(getApplicationContext());
    }
}
