package adapter;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.example.enock.retrofit.R;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import activity.MainActivity;
import model.Constants;

/**
 * Created by Enock on 8/18/2016.
 */
public class NotificationListener extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /*When the service is started
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //Opening sharedpreferences
      /*  showNotification("Your Leave Application has gone Through First Approver. Enock");

        //Getting the firebase id from sharedpreferences


        //Creating a firebase object
        Firebase firebase = new Firebase("https://fir-notifications-97e8e.firebaseio.com/");
        //showNotification("Hallo Thea");
        //Adding a valueevent listener to firebase
        //this will help us to  track the value changes on firebase
        firebase.addValueEventListener(new ValueEventListener() {

            //This method is called whenever we change the value in firebase
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                SharedPreferences sharedPreferences = getSharedPreferences(Constants.SHARED_PREF, MODE_PRIVATE);
                String id = sharedPreferences.getString(Constants.UNIQUE_ID, null);
                //Getting the value from firebase
                //We stored none as a initial value
                Toast.makeText(getApplicationContext(),"xxxxxxxxxxxxxxx",Toast.LENGTH_LONG).show();
                String msg = snapshot.child("msg").getValue().toString();

                //So if the value is none we will not create any notification
                if (msg.equals("none"))
                    return;

                //If the value is anything other than none that means a notification has arrived
                //calling the method to show notification
                //String msg is containing the msg that has to be shown with the notification
                showNotification(msg);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                Log.e("The read failed: ", firebaseError.getMessage());
            }
        });

        return START_STICKY;
    }


    public void showNotification(String msg){
        //Creating a notification
       /* Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.drawable.calendar_icon);
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.simplifiedcoding.net"));
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        builder.setContentIntent(pendingIntent);
        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_profile));
        builder.setContentTitle("Leave Notification");
        builder.setContentText(msg);
        Notification notification = builder.build();
        notification.defaults |= Notification.DEFAULT_VIBRATE;
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(1, builder.build());
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.simplifiedcoding.net"));
        PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, 0);
        Notification mNotification = new Notification.Builder(this)
                .setContentTitle("Leave Notification")
                .setContentText("Your Leave Application has been Approved by First Approver. (Nyagaka Enock)")
                .setSmallIcon(R.mipmap.ic_icon)
                .setContentIntent(pIntent)
                .build();
        mNotification.defaults |= Notification.DEFAULT_SOUND;
        mNotification.defaults |= Notification.DEFAULT_VIBRATE;
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(0, mNotification);
    }*/
}
