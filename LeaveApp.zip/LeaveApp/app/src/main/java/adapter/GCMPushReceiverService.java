package adapter;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.text.Html;

import com.example.enock.retrofit.R;
import com.google.android.gms.gcm.GcmListenerService;

import java.util.Random;

import activity.MainActivity;

/**
 * Created by Enock on 8/19/2016.
 */
public class GCMPushReceiverService extends GcmListenerService {
    //This method will be called on every new message received
    @Override
    public void onMessageReceived(String from, Bundle data) {
        //Getting the message from the bundle
        String message =data.getString("message");
        String title =data.getString("Subject");
        //Displaying a notiffication with the message
        showNotification(message,title);
    }


    public void showNotification(String msg,String title){
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, 0);
        Notification mNotification = new Notification.Builder(this)
                .setContentTitle(title)
                .setContentText(Html.fromHtml(msg))
                .setSmallIcon(R.mipmap.ic_icon)
                .setContentIntent(pIntent)
                .build();
        mNotification.defaults |= Notification.DEFAULT_SOUND;
        mNotification.defaults |= Notification.DEFAULT_VIBRATE;
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Random random = new Random();
        int m = random.nextInt(9999 - 1000) + 1000;

        notificationManager.notify(m, mNotification);
    }
}
