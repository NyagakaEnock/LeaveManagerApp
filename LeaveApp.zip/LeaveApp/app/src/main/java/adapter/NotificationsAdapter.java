package adapter;

import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.enock.retrofit.R;

import java.util.List;

import model.LeaveDetails;
import model.NotificationDetails;

/**
 * Created by Enock on 9/15/2016.
 */
public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.MyViewHolder> {

    private List<NotificationDetails> notificationList;

    public NotificationsAdapter(List<NotificationDetails> notificationList) {
        this.notificationList = notificationList;
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView Subject,Message,DateSent;

        public MyViewHolder(View view) {
            super(view);
            Subject = (TextView) view.findViewById(R.id.Subject);
            Message = (TextView) view.findViewById(R.id.Message);
            DateSent = (TextView) view.findViewById(R.id.DateSent);



        }
    }

    public void onBindViewHolder(MyViewHolder holder, int position) {
        NotificationDetails notificationDetails = notificationList.get(position);
        holder.Subject.setText(Html.fromHtml(notificationDetails.getSubject()));
        holder.Message.setText(Html.fromHtml(notificationDetails.getMessage()));
        holder.DateSent.setText(notificationDetails.getDateSent());

    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.notification_recyclerview, parent, false);

        return new MyViewHolder(itemView);
    }


    @Override
    public int getItemCount() {
        return notificationList.size();
    }

    public void clearData() {
        int size = this.notificationList.size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                this.notificationList.remove(0);
            }

            this.notifyItemRangeRemoved(0, size);
        }
    }
}
