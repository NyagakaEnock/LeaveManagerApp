package adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.enock.retrofit.R;

import java.util.List;

import model.LeaveSummary;
import model.Movie;

/**
 * Created by Enock on 8/22/2016.
 */
public class LeaveSummaryAdapter extends RecyclerView.Adapter<LeaveSummaryAdapter.MyViewHolder>  {
    private List<LeaveSummary> LeaveSummaryList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private  TextView DateApplied,Entitlement,BeforeApplication,Status,StartDate,EndDate,ReturnDate,LeaveDesc,ApplicationNo,DaysApplied;

        public MyViewHolder(View view) {
            super(view);
            DateApplied = (TextView) view.findViewById(R.id.LDateApplied);
            Entitlement = (TextView) view.findViewById(R.id.LEntitlement);
            BeforeApplication = (TextView) view.findViewById(R.id.LBeforeApplication);
            Status = (TextView) view.findViewById(R.id.LStatus);
            StartDate = (TextView) view.findViewById(R.id.LStartDate);
            EndDate = (TextView) view.findViewById(R.id.LEndDate);
            ReturnDate = (TextView) view.findViewById(R.id.LReturnDate);
            LeaveDesc = (TextView) view.findViewById(R.id.LeaveDescxx);
            ApplicationNo = (TextView) view.findViewById(R.id.ApplicationNo);
            DaysApplied = (TextView) view.findViewById(R.id.DaysApplied);
        }
    }

    public LeaveSummaryAdapter(List<LeaveSummary> leaveSummaryList) {
        this.LeaveSummaryList = leaveSummaryList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.leave_summary_recyclerview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        LeaveSummary leaveSummary = LeaveSummaryList.get(position);
        holder.DateApplied.setText(leaveSummary.getDateApplied());
        holder.Entitlement.setText(leaveSummary.getEntitlement());
        holder.BeforeApplication.setText(leaveSummary.getBeforeApplication());
        holder.Status.setText(leaveSummary.getStatus());
        holder.StartDate.setText(leaveSummary.getStartDate());
        holder.EndDate.setText(leaveSummary.getEndDate());
        holder.ReturnDate.setText(leaveSummary.getReturnDate());
       holder.LeaveDesc.setText(leaveSummary.getLeaveDesc());
        holder.ApplicationNo.setText(leaveSummary.getApplicationNo());
        holder.DaysApplied.setText(leaveSummary.getDaysApplied());

    }

    @Override
    public int getItemCount() {
        return LeaveSummaryList.size();
    }
}
