package adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.enock.retrofit.R;

import java.util.List;

import model.LeaveDetails;
import model.LeaveSummary;

/**
 * Created by Enock on 8/30/2016.
 */
public class LeaveDetailsAdapter extends RecyclerView.Adapter<LeaveDetailsAdapter.MyViewHolder>  {
    private List<LeaveDetails> leaveDetailsList;

    public LeaveDetailsAdapter(List<LeaveDetails> leaveDetailsList) {
        this.leaveDetailsList = leaveDetailsList;
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView Entitlement,BroughtForward,LeaveEarne,LeaveTaken,LeaveForfeited,LeaveBalance,EnYrBalance,Description;

        public MyViewHolder(View view) {
            super(view);
            Entitlement = (TextView) view.findViewById(R.id.DEntitlement);
            BroughtForward = (TextView) view.findViewById(R.id.DBfwd);
            LeaveEarne = (TextView) view.findViewById(R.id.DLeaveEarned);
            LeaveTaken = (TextView) view.findViewById(R.id.DLeaveTaken);
            LeaveForfeited = (TextView) view.findViewById(R.id.DLeaveForfeited);
            LeaveBalance = (TextView) view.findViewById(R.id.DLeaveBal);
            EnYrBalance = (TextView) view.findViewById(R.id.DEndYrBal);
            Description = (TextView) view.findViewById(R.id.descxx);



        }
    }
    public void onBindViewHolder(MyViewHolder holder, int position) {
        LeaveDetails leaveDetails = leaveDetailsList.get(position);
        holder.Entitlement.setText(leaveDetails.getEntitlement());
        holder.BroughtForward.setText(leaveDetails.getBroughtForward());
        holder.LeaveEarne.setText(leaveDetails.getLeaveEarne());
        holder.LeaveTaken.setText(leaveDetails.getLeaveTaken());
        holder.LeaveForfeited.setText(leaveDetails.getLeaveForfeited());
        holder.LeaveBalance.setText(leaveDetails.getLeaveBalance());
        holder.EnYrBalance.setText(leaveDetails.getEnYrBalance());
        holder.Description.setText(leaveDetails.getDescription());

    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.leave_details_recycler_view, parent, false);

        return new MyViewHolder(itemView);
    }


    @Override
    public int getItemCount() {
        return leaveDetailsList.size();
    }


}
