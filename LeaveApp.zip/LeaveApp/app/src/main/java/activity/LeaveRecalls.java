package activity;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import adapter.MoviesAdapter;
import adapter.RecallsAdapter;
import adapter.RecyclerAdapter;
import model.Movie;
import model.Recalls;

/**
 * A simple {@link Fragment} subclass.
 */
public class LeaveRecalls extends Fragment {
    private List<Recalls> movieList = new ArrayList<>();
    private RecyclerView recyclerView;
    private RecallsAdapter mAdapter;

    public LeaveRecalls() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_leave_recalls, container, false);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.reacallsrecycler_view);
        mAdapter = new RecallsAdapter(movieList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);
        prepareData();
        return rootView;
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }
    private void prepareData() {
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("Recalls");

            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String EmployeeName = LeaveApplicationObject.getString("AllNames");
                String LeaveType = LeaveApplicationObject.getString("Descriptions");
                String DateApplied =  LeaveApplicationObject.getString("AprDateExpected").substring(0,10);

                Recalls recalls = new Recalls(EmployeeName, LeaveType, DateApplied);
                movieList.add(recalls);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
    }
    public static class RecyclerItemListner implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private Approve.ClickListener clickListener;

        public RecyclerItemListner(Context context, final RecyclerView recyclerView, final Approve.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {

                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
