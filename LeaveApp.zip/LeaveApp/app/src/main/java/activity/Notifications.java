package activity;


import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import adapter.LeaveSummaryAdapter;
import adapter.NotificationsAdapter;
import model.EmployeeAPI;
import model.GlobalRecordFetch;
import model.LeaveSummary;
import model.Movie;
import model.NotificationDetails;
import model.RefreshApp;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class Notifications extends Fragment {
    private List<NotificationDetails> notificationDetailsListList = new ArrayList<>();
    private RecyclerView recyclerView;
    private NotificationsAdapter mAdapter;
     boolean loading = true;
     int pastVisiblesItems;
     int visibleItemCount;
     int totalItemCount;
    SwipeRefreshLayout mSwipeRefreshLayout;
    public Notifications() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_notifications, container, false);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.notificationrecycler_view);
        mSwipeRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.swipeRefreshLayout);
        mAdapter = new NotificationsAdapter(notificationDetailsListList);
        final RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);
        prepareData();
        recyclerView.addOnItemTouchListener(new FragmentDrawer.RecyclerTouchListener(getActivity(), recyclerView, new FragmentDrawer.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                NotificationDetails notificationDetails = notificationDetailsListList.get(position);
                Fragment fragment = null;
                fragment =  new ReadNotification();
                if (fragment != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString("NotificationDetails",notificationDetails.getJsonObject().toString());
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Read Notification");
                }

            }

            @Override
            public void onLongClick(View view, final int position) {
                    new AlertDialog.Builder(getActivity())
                            .setTitle("Confirm Delete?")
                            .setMessage("Are you sure you want to Delete this Notification?")
                            .setNegativeButton(android.R.string.no, null)
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface arg0, int arg1) {
                                    try{
                                    NotificationDetails notificationDetails = notificationDetailsListList.get(position);
                                    String JsonData = notificationDetails.getJsonObject().toString();
                                    JSONObject jsonObject = new JSONObject(JsonData);
                                    final String ID = jsonObject.getString("ID");

                                    DeleteNotifications(ID);
                                    }catch (JSONException e){
                                        e.printStackTrace();
                                    }
                                }
                            }).create().show();



            }
        }));

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                final String StaffIDNO = prefs.getString("StaffIDNO", "");
                refreshNotifications(StaffIDNO);
            }
        });

        return rootView;
    }
    void DeleteNotifications(String Id) {
        RestAdapter.Builder builder = new RestAdapter.Builder();
         GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.DeleteNotifications(
                Id,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            Toast.makeText(getActivity(), output,Toast.LENGTH_LONG).show();
                            SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                            final String StaffIDNO = prefs.getString("StaffIDNO", "");
                            //refreshNotifications(StaffIDNO);

                            new RefreshApp(getActivity()).execute(StaffIDNO);
                            onItemsLoadComplete();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void failure(RetrofitError error) {
                        onItemsLoadComplete();
                        Toast.makeText(getActivity(), "Connection Failed. Please Try Again.",Toast.LENGTH_LONG).show();
                    }
                }
        );

    }
    void refreshNotifications(final String StaffId) {
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.refreshNotifications(
                StaffId,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            new RefreshApp(getActivity()).execute(StaffId);
                            onItemsLoadComplete();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void failure(RetrofitError error) {
                        onItemsLoadComplete();
                        Toast.makeText(getActivity(), "Connection Failed. Please Try Again.",Toast.LENGTH_LONG).show();
                    }
                }
        );

    }

    void onItemsLoadComplete() {
        mAdapter = new NotificationsAdapter(notificationDetailsListList);
        final RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);
        mAdapter.clearData();
        prepareData();
        mSwipeRefreshLayout.setRefreshing(false);
    }
    private void prepareData() {
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("Notifications");
            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String Subject = LeaveApplicationObject.getString("Subject");
                String Message = LeaveApplicationObject.getString("Message");
                String DateSent = LeaveApplicationObject.getString("DateCreated");
                NotificationDetails notificationDetails = new NotificationDetails(Subject,Message,DateSent,LeaveApplicationObject);
                notificationDetailsListList.add(notificationDetails);
            }
            jsonObject=null;
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }
    public static class RecyclerItemListner implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private LeaveSummaryTab.ClickListener clickListener;

        public RecyclerItemListner(Context context, final RecyclerView recyclerView, final LeaveSummaryTab.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {

                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
