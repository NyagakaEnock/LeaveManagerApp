package activity;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import adapter.LeaveDetailsAdapter;
import adapter.LeaveSummaryAdapter;
import model.LeaveDetails;
import model.LeaveSummary;
import model.RefreshApp;

/**
 * A simple {@link Fragment} subclass.
 */
public class LeaveDetailsTab extends Fragment {
    private List<LeaveDetails> leaveDetailsList = new ArrayList<>();
    private RecyclerView recyclerView;
    private LeaveDetailsAdapter mAdapter;
private Spinner yearsspinner;
    public LeaveDetailsTab() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_leave_details_tab, container, false);
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String StaffId = prefs.getString("StaffIDNO", null);
        new RefreshApp(getActivity()).execute(StaffId);
       yearsspinner = (Spinner)rootView.findViewById(R.id.yearsspinner);
        List<String> years =  new ArrayList<String>();
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("getYears");
            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject TownObject = jresult.getJSONObject(i);
                years.add(TownObject.getString("CurrentYear"));
            }
        }catch (JSONException e){
            e.printStackTrace();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, years);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearsspinner.setAdapter(adapter);
        yearsspinner.setOnItemSelectedListener(new CustomOnItemSelectedListener());
        recyclerView = (RecyclerView) rootView.findViewById(R.id.detailsrecycler_view);
        mAdapter = new LeaveDetailsAdapter(leaveDetailsList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);
        prepareMovieData();
        return rootView;
    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        String firstItem = String.valueOf(yearsspinner.getSelectedItem());

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            if (firstItem.equals(String.valueOf(yearsspinner.getSelectedItem()))) {
                // ToDo when first item is selected
            } else {

            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> arg) {

        }

    }


    private void prepareMovieData() {
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("LeaveDetails");
            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String Entment = LeaveApplicationObject.getString("Ent'ment");
                String BroughtForward = LeaveApplicationObject.getString("Leave Bfwd");
                String LeaveEarned = LeaveApplicationObject.getString("Leave Earned");
                String LeaveTaken = LeaveApplicationObject.getString("Leave Taken");
                String LeaveForfeited = LeaveApplicationObject.getString("Leave Forfeited");
                String LeaveBal = LeaveApplicationObject.getString("Leave Bal");
                String EndYrBal = LeaveApplicationObject.getString("End Yr. Bal");
                String Description = LeaveApplicationObject.getString("Leave Type");

                LeaveDetails leaveDetails = new LeaveDetails(Entment,BroughtForward ,LeaveEarned,LeaveTaken,LeaveForfeited,LeaveBal,EndYrBal,Description);
                leaveDetailsList.add(leaveDetails);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
    }
}
