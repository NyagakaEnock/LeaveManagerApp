package activity;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import adapter.LeaveSummaryAdapter;
import adapter.MoviesAdapter;
import model.LeaveSummary;
import model.Movie;

/**
 * A simple {@link Fragment} subclass.
 */
public class LeaveSummaryTab extends Fragment {
    private List<LeaveSummary> leaveSummaryList = new ArrayList<>();
    private RecyclerView recyclerView;
    private LeaveSummaryAdapter mAdapter;

    public LeaveSummaryTab() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_leave_summary_tab, container, false);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.summaryrecycler_view);

        mAdapter = new LeaveSummaryAdapter(leaveSummaryList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);
        prepareMovieData();
        recyclerView.addOnItemTouchListener(new FragmentDrawer.RecyclerTouchListener(getActivity(), recyclerView, new FragmentDrawer.ClickListener() {
            @Override
            public void onClick(View view, int position) {
               /* LeaveSummary leaveSummary = leaveSummaryList.get(position);
                Fragment fragment = null;
                fragment =  new ConfirmLeaveApplication();
                if (fragment != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString("LeaveApplicationDetails",movie.getJsonObject().toString());
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Confirm Leave Application");
                }*/

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        return rootView;
    }
    private void prepareMovieData() {
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("LeaveSummary");
            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String DateApplied = LeaveApplicationObject.getString("DateApplied").substring(0,10);
                String CurrentLeave = LeaveApplicationObject.getString("CurrentLeave");
                String Entitlement = LeaveApplicationObject.getString("LeaveEntitlement");
                String Status;
                if(LeaveApplicationObject.getString("Approved").equals("1"))
                {
                    if(LeaveApplicationObject.getString("Authorized").equals("1"))
                    {
                        if(LeaveApplicationObject.getString("Authorized").equals("0"))
                        {
                            Status="Cancelled";
                        }else{
                            Status="Authorized";
                        }
                    }else{
                       Status = "Approved";
                    }
                }else  if(LeaveApplicationObject.getString("Approved").equals("0"))
                {
                    Status = "Rejected";
                }else  if(LeaveApplicationObject.getString("Approved").equals("")||LeaveApplicationObject.getString("Approved").equals("null"))
                {
                    Status = "Pending";
                }else{
                    Status = "Pending";
                }

                String LeaveDesc = LeaveApplicationObject.getString("Descriptions");
                String StartDate = LeaveApplicationObject.getString("StartDate").substring(0,10);
                String LastDate = LeaveApplicationObject.getString("LastDate").substring(0,10);
                String DateExpected = LeaveApplicationObject.getString("DateExpected").substring(0,10);
                String ApplicationNo  = LeaveApplicationObject.getString("AppNum");
                String DaysApplied  = LeaveApplicationObject.getString("DaysApplied");
                LeaveSummary leaveSummary = new LeaveSummary(DateApplied,Entitlement,CurrentLeave,Status,StartDate,LastDate,DateExpected,LeaveDesc,ApplicationNo,DaysApplied);
                leaveSummaryList.add(leaveSummary);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerItemListner implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private LeaveSummaryTab.ClickListener clickListener;

        public RecyclerItemListner(Context context, final RecyclerView recyclerView, final LeaveSummaryTab.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {

                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
