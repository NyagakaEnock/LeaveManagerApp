package activity;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import model.RefreshApp;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedFile;

/**
 * A simple {@link Fragment} subclass.
 */
public class Profile extends Fragment {
private static ImageView imageView;
    private Resources mResources;
    private Bitmap mBitmap;
    private TextView staffid,name,email,tel,department,level,firstapprover,altapprover,JobTitle,AlternaFinalteApprover,ThirdApprover,AlternaSecondteApprover,SecondApprover;
    public Profile() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);
        FloatingActionButton fab = (FloatingActionButton) rootView.findViewById(R.id.fab);
        imageView = (ImageView) rootView.findViewById(R.id.imageView3);
        staffid = (TextView) rootView.findViewById(R.id.EmpStaffIDNo);
        name = (TextView) rootView.findViewById(R.id.EmployeeName);
        email=(TextView) rootView.findViewById(R.id.EmployeeEmail);
        tel=(TextView) rootView.findViewById(R.id.EmployeePhone);
        department=(TextView) rootView.findViewById(R.id.Department);
        level=(TextView) rootView.findViewById(R.id.ApprovalLevel);
        firstapprover=(TextView) rootView.findViewById(R.id.FirstApprover);
        altapprover=(TextView) rootView.findViewById(R.id.AlternateApprover);

        SecondApprover=(TextView) rootView.findViewById(R.id.SecondApprover);
        AlternaSecondteApprover=(TextView) rootView.findViewById(R.id.AlternaSecondteApprover);

        ThirdApprover=(TextView) rootView.findViewById(R.id.ThirdApprover);
        AlternaFinalteApprover=(TextView) rootView.findViewById(R.id.AlternaFinalteApprover);

        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        mResources = getResources();

        try {
            GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
            String jsonResponce = prefs.getString("jsonResponce", null);
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("result");
            JSONArray FirstApprover = jsonObject.getJSONArray("FirstApprover");
            JSONArray AltFirstApprover = jsonObject.getJSONArray("AltFirstApprover");

            JSONArray SecondApproverArr = jsonObject.getJSONArray("SecondApprover");
            JSONArray AltSecondApprover = jsonObject.getJSONArray("AltSecondApprover");

            JSONArray ThirdApproverArr = jsonObject.getJSONArray("ThirdApprover");
            JSONArray AltThirdApprover = jsonObject.getJSONArray("AltThirdApprover");

            JSONArray Department = jsonObject.getJSONArray("Depts");
            JSONObject FirstApproverobject = FirstApprover.getJSONObject(FirstApprover.length() - 1);
            JSONObject AltFirstApproverobject = AltFirstApprover.getJSONObject(AltFirstApprover.length() - 1);
            JSONObject Departmentobject = Department.getJSONObject(AltFirstApprover.length() - 1);
            String Second = "Not Set";
            String AltSecond = "Not Set";
            String Third = "Not Set";
            String AltThird= "Not Set";

            if(SecondApproverArr.length()==1)
            {
                JSONObject SecondApprobject = SecondApproverArr.getJSONObject(0);
                Second = SecondApprobject.getString("AllNames");
            }
            if(AltSecondApprover.length()==1)
            {
                JSONObject AltSecondApproverobject = AltSecondApprover.getJSONObject(0);
                AltSecond = AltSecondApproverobject.getString("AllNames");
            }
            if(ThirdApproverArr.length()==1)
            {
                JSONObject ThirdApprobject = ThirdApproverArr.getJSONObject(0);
                Third = ThirdApprobject.getString("AllNames");
            }
            if(AltThirdApprover.length()==1)
            {
                JSONObject AltThirdApproverobject = AltThirdApprover.getJSONObject(0);
                AltThird = AltThirdApproverobject.getString("AllNames");
            }
            JSONObject object = jresult.getJSONObject(jresult.length() - 1);
            name.setText(object.getString("AllNames"));
            staffid.setText(object.getString("StaffIDNO"));
            email.setText(object.getString("ContEmail"));
            tel.setText(object.getString("contmobile"));
            level.setText(object.getString("ApprovalLevel"));
            firstapprover.setText(FirstApproverobject.getString("AllNames"));
            altapprover.setText(AltFirstApproverobject.getString("AllNames"));
            SecondApprover.setText(Second);
            AlternaSecondteApprover.setText(AltSecond);
            ThirdApprover.setText(Third);
            AlternaFinalteApprover.setText(AltThird);

            department.setText(Departmentobject.getString("DeptName"));
            String path = globalRecordFetch.ROOT_URL+"/uploads/" + object.getString("Photo");
            String NoImagepath = globalRecordFetch.ROOT_URL+"/uploads/noImage.png";
            if(object.getString("Photo").equals("")||object.getString("Photo").equals("null"))
            {
                new DownLoadImageTask(imageView).execute(NoImagepath);
            }else {
                new DownLoadImageTask(imageView).execute(path);
            }


        }catch (JSONException e)
        {
e.printStackTrace();
        }

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Click action
                Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, 2);
            }
        });
        return rootView;
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if ( resultCode == Activity.RESULT_OK) {

            String path = getPathFromCameraData(data, this.getActivity());

            if (path != null) {

                TypedFile file = new TypedFile("multipart/form-data", new File(path));
                SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                final String StaffIDNO = prefs.getString("StaffIDNO", "");
                UploadFile(file,StaffIDNO);
            }
        }
    }

    public static String getPathFromCameraData(Intent data, Context context) {
        Uri selectedImage = data.getData();

        String[] filePathColumn = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(selectedImage,
                filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();
        String fileName = selectedImage.getLastPathSegment().toString();

        return picturePath;
    }

    public void UploadFile(final TypedFile file, final String StaffId) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
       final  GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.UploadFile(
                file,
                StaffId,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            MyalertDialog(output);
                            new RefreshApp(getActivity()).execute(StaffId);
                                    try{
                                        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                                        String jsonResponce = prefs.getString("jsonResponce", null);
                                        JSONObject jsonObject = new JSONObject(jsonResponce);
                                        JSONArray jresult = jsonObject.getJSONArray("result");
                                        JSONObject object = jresult.getJSONObject(jresult.length() - 1);
                                    String path = globalRecordFetch.ROOT_URL+"/uploads/" + object.getString("Photo");
                                    String NoImagepath = globalRecordFetch.ROOT_URL+"/uploads/noImage.png";
                                    if(object.getString("Photo").equals("")||object.getString("Photo").equals("null"))
                                    {
                                    new DownLoadImageTask(imageView).execute(NoImagepath);
                                    }else {
                                    new DownLoadImageTask(imageView).execute(path);
                                    }
                                    }catch (JSONException e)
                                    {
                                    e.printStackTrace();
                                    }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        MyalertDialog( error.toString());
                    }
                }
        );


    }
    public void MyalertDialog(String msg)
    {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Response")
                .setMessage(msg)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.ok, null).show();


    }

    public class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {


        public DownLoadImageTask(ImageView imageView) {
            Profile.imageView = imageView;
        }

        /*
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String... urls) {
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try {
                InputStream is = new URL(urlOfImage).openStream();
                logo = BitmapFactory.decodeStream(is);
            } catch (Exception e) { // Catch the download exception
                e.printStackTrace();
            }

            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result) {


           // mBitmap = BitmapFactory.decodeResource(mResources,R.drawable.boy);
            mBitmap = result;
            RoundedBitmapDrawable drawable = createRoundedBitmapDrawableWithBorder(mBitmap);

           // imageView.setImageBitmap(result);
            // Set the ImageView image as drawable object
            imageView.setImageDrawable(drawable);
        }

    }
    public RoundedBitmapDrawable createRoundedBitmapDrawableWithBorder(Bitmap bitmap){
        RoundedBitmapDrawable roundedBitmapDrawable=null;
        try
        {
        int bitmapWidth = bitmap.getWidth();
        int bitmapHeight = bitmap.getHeight();
        int borderWidthHalf = 10; // In pixels
        int bitmapRadius = Math.min(bitmapWidth,bitmapHeight)/2;
        int bitmapSquareWidth = Math.min(bitmapWidth,bitmapHeight);
        int newBitmapSquareWidth = bitmapSquareWidth+borderWidthHalf;
        Bitmap roundedBitmap = Bitmap.createBitmap(newBitmapSquareWidth,newBitmapSquareWidth,Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(roundedBitmap);
        canvas.drawColor(Color.parseColor("#1DA1F2"));
        int x = borderWidthHalf + bitmapSquareWidth - bitmapWidth;
        int y = borderWidthHalf + bitmapSquareWidth - bitmapHeight;
        canvas.drawBitmap(bitmap, x, y, null);
        Paint borderPaint = new Paint();
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(borderWidthHalf*2);
        borderPaint.setColor(Color.parseColor("#FF9933"));
        canvas.drawCircle(canvas.getWidth()/2, canvas.getWidth()/2, newBitmapSquareWidth/2, borderPaint);
         roundedBitmapDrawable = RoundedBitmapDrawableFactory.create(mResources,roundedBitmap);
        roundedBitmapDrawable.setCornerRadius(bitmapRadius);
        roundedBitmapDrawable.setAntiAlias(true);
    }catch (NullPointerException e)
    {
        e.printStackTrace();
    }
    return roundedBitmapDrawable;
    }

}
