package activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by Enock on 8/11/2016.
 */
public class Login extends AppCompatActivity implements View.OnClickListener{
    private TextView emailAdress;
    private  TextView passWord;
    public String output;
    private Button loginButton;
    private  Toolbar mToolbar;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        mToolbar = (Toolbar) findViewById(R.id.toolbar);


        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        emailAdress = (TextView)findViewById(R.id.loginEmail);
        passWord = (TextView)findViewById(R.id.Password);
        loginButton = (Button)findViewById(R.id.btnLogin);
        loginButton.setOnClickListener(this);
        // Check if no view has focus:
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

        }
    }
public void onClick(View view)
{
    String email = emailAdress.getText().toString();
    String password = passWord.getText().toString();
    Login(email, password);
}
    public void Login(final String email, String password) {

        final ProgressDialog loading = ProgressDialog.show(Login.this, "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        final GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getApplicationContext());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.Login(
                email,
                password,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                          if(!output.equals("False"))
                           {

                              Intent intent = new Intent(Login.this, MainActivity.class);
                               SharedPreferences.Editor editor = getSharedPreferences("MySessions", MODE_PRIVATE).edit();
                               editor.putString("jsonResponce",output);
                               editor.commit();
                              startActivity(intent);
                               finish();

                           }else {

                              Toast.makeText(getApplicationContext(), "Access Denied. Check your Username and Password and try again",Toast.LENGTH_LONG).show();;
                           }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getApplicationContext(), "Try again "+error.toString(),Toast.LENGTH_LONG).show();
                    }
                }
        );


    }


}
