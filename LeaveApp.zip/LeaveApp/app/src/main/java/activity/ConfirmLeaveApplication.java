package activity;


import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;
import com.squareup.okhttp.OkHttpClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import model.RefreshApp;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.OkClient;
import retrofit.client.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class ConfirmLeaveApplication extends Fragment {

    private int mYear, mMonth, mDay;
    private TextView startDate;
    private TextView Expected;
    private Button Confirm;
    private CheckBox checkBox2;
    private TextView StaffIDNo;
    private TextView fullnames;
    private TextView LeaveType;
    private TextView start;
    private TextView end;
    private TextView noofDays;
    private TextView comments,comments2,Expected1,txtAppNumber;
    public ConfirmLeaveApplication() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_confirm_leave_application, container, false);
        startDate = (TextView)rootView.findViewById(R.id.startda);
        start = (TextView)rootView.findViewById(R.id.startDate);
        end = (TextView)rootView.findViewById(R.id.lastDate);
        Expected = (TextView)rootView.findViewById(R.id.Expected);
        Expected1 = (TextView)rootView.findViewById(R.id.Expected2);
        fullnames = (TextView)rootView.findViewById(R.id.fullnames);
        noofDays = (TextView)rootView.findViewById(R.id.noofDays);
        comments= (TextView)rootView.findViewById(R.id.comments);
        comments2= (TextView)rootView.findViewById(R.id.comments2);
        StaffIDNo = (TextView)rootView.findViewById(R.id.StaffIDNo);
        LeaveType = (TextView)rootView.findViewById(R.id.LeaveType);
        Confirm =(Button)rootView.findViewById(R.id.Confirm);
        txtAppNumber = (TextView)rootView.findViewById(R.id.txtAppNumber);
        checkBox2 = (CheckBox)rootView.findViewById(R.id.checkBox2);
        checkBox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                androidCheckBoxClicked(checkBox2,checkBox2);
            }
        });
        startDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus==true) {
                    getDate(startDate);
                }
            }
        });
        Expected.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus==true) {
                    getDate(Expected);
                }
            }
        });
        Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              if(validateData()==true)
              {
                  final  String Leave =LeaveType.getText().toString();
                  SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                  final String GetCurrentStaffID = prefs.getString("StaffIDNO", "");
                  final String strStartdate = startDate.getText().toString();
                  final String strLastDate = end.getText().toString();
                  final String StaffIDNO = StaffIDNo.getText().toString();
                  final String strDateExpected = Expected.getText().toString();
                  final String txtDaysApplied = noofDays.getText().toString();
                  final String AppNumber =txtAppNumber.getText().toString();
                   String chkRequireLeaveAllowance="";
                  if(checkBox2.isChecked()==true)
                  {
                       chkRequireLeaveAllowance ="0";
                  }else
                  {
                      chkRequireLeaveAllowance ="1";
                  }

                  final String txtComments = comments2.getText().toString();
                  int itemsCounter = getArguments().getInt("itemsCounter",0);

                  if(itemsCounter==2)
                  {
                      SecondApproval(StaffIDNO,Leave,strStartdate,strLastDate,strDateExpected,chkRequireLeaveAllowance,txtDaysApplied,GetCurrentStaffID,txtComments,AppNumber);

                  }else if(itemsCounter==3)
                  {
                      FinalApproval(StaffIDNO,Leave,strStartdate,strLastDate,strDateExpected,chkRequireLeaveAllowance,txtDaysApplied,GetCurrentStaffID,txtComments,AppNumber);
                  }
                  else
                  {
                      FirstApproval(StaffIDNO, Leave, strStartdate, strLastDate, strDateExpected, chkRequireLeaveAllowance, txtDaysApplied, GetCurrentStaffID, txtComments, AppNumber);
                  }


                  //refreshNotifications(StaffIDNO);

                  new RefreshApp(getActivity()).execute(StaffIDNO);
                  Fragment fragment = new Approve();
                  if (fragment != null) {
                      FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                      FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                      fragmentTransaction.replace(R.id.container_body, fragment);
                      fragmentTransaction.commit();
                      ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Leave Approval");
                  }

              }
            }
        });
        getData();
        return rootView;
    }

    private void getData()
    {
        String LeaveApplicationDetails = getArguments().getString("LeaveApplicationDetails","NULL");
        try{
            JSONObject jsonObject = new JSONObject(LeaveApplicationDetails);
            StaffIDNo.setText(jsonObject.getString("StaffIDNo"));
            fullnames.setText(jsonObject.getString("AllNames"));
            LeaveType.setText(jsonObject.getString("Descriptions"));
            startDate.setText(jsonObject.getString("StartDate").substring(0,10));
            start.setText(jsonObject.getString("StartDate").substring(0,10));
            end.setText(jsonObject.getString("LastDate").substring(0,10));
            Expected.setText(jsonObject.getString("DateExpected").substring(0,10));
            noofDays.setText(jsonObject.getString("DaysApplied"));
            comments.setText(jsonObject.getString("Comment"));
            Expected1.setText(jsonObject.getString("DateExpected").substring(0,10));
            txtAppNumber.setText(jsonObject.getString("AppNum"));
        }catch (JSONException e){
            e.printStackTrace();
        }
    }
    public void getDate(final TextView v)
    {

        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // Launch Date Picker Dialog
        DatePickerDialog dpd = new DatePickerDialog(getActivity(),
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        // Display Selected date in textbox

                        v.setText(year + "-"
                                + (monthOfYear + 1) + "-" + dayOfMonth);

                    }
                }, mYear, mMonth, mDay);
        dpd.show();

    }
    private boolean validateData()
    {
       boolean state = false;
        if(startDate.length()==0)
        {
            Toast.makeText(getActivity(),"Approval Start Date Required",Toast.LENGTH_LONG).show();
            state = false;
        }else if(Expected.length()==0)
        {
            Toast.makeText(getActivity(),"Approval Expected Date Required",Toast.LENGTH_LONG).show();
            state = false;
        }else if(checkBox2.isChecked()==true && comments2.length()==0)
        {
            Toast.makeText(getActivity(),"Reason for Rejection is Required",Toast.LENGTH_LONG).show();
            state = false;
        }else if(daysBetween(stringToDate(startDate.getText().toString(),"yyyy-MM-dd"),stringToDate(Expected.getText().toString(),"yyyy-MM-dd"))<=1)
        {
            Toast.makeText(getActivity(),"Wrong Dates Selected.",Toast.LENGTH_LONG).show();
        }else{

            state = true;
        }
        return  state;
    }
    public Date stringToDate(String aDate, String aFormat) {
        if(aDate==null) return null;
        ParsePosition pos = new ParsePosition(0);
        SimpleDateFormat simpledateformat = new SimpleDateFormat(aFormat);
        Date stringDate = simpledateformat.parse(aDate, pos);
        return stringDate;
    }
    public static long daysBetween(Date startDate, Date endDate) {
            return (endDate.getTime() - startDate.getTime());
    }
    public void androidCheckBoxClicked(View view, final CheckBox checkBox) {
        // action for checkbox click
        switch (view.getId()) {
            case R.id.checkBox2:
                if(checkBox.isChecked()==true)
                {
                    Confirm.setText("Reject");
                }else {
                    Confirm.setText("Confirm");
                }


                break;

        }
    }

    public void  FirstApproval(String StaffIDNO,String Leave,String strStartdate,String strLastDate,String strDateExpected,String chkRequireLeaveAllowance,String txtDaysApplied,String GetCurrentStaffID,String txtComments,String AppNumber) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setReadTimeout(60 * 1000, TimeUnit.MILLISECONDS);
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setClient(new OkClient(okHttpClient));
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.FirstApproval(
                StaffIDNO,
                Leave,
                strStartdate,
                strLastDate,
                strDateExpected,
                chkRequireLeaveAllowance,
                txtDaysApplied,
                GetCurrentStaffID,
                txtComments,
                AppNumber,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            if(output.equals(""))
                            {
                                output = "Leave Approval Successful";
                            }
                            MyalertDialog(output);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getActivity(), error.toString(),Toast.LENGTH_LONG).show();
                    }
                }
        );


    }

    public void  SecondApproval(String StaffIDNO,String Leave,String strStartdate,String strLastDate,String strDateExpected,String chkRequireLeaveAllowance,String txtDaysApplied,String GetCurrentStaffID,String txtComments,String AppNumber) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setReadTimeout(60 * 1000, TimeUnit.MILLISECONDS);
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setClient(new OkClient(okHttpClient));
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.SecondApproval(
                StaffIDNO,
                Leave,
                strStartdate,
                strLastDate,
                strDateExpected,
                chkRequireLeaveAllowance,
                txtDaysApplied,
                GetCurrentStaffID,
                txtComments,
                AppNumber,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            if(output.equals(""))
                            {
                                output = "Leave Approval Successful";
                            }
                            MyalertDialog(output);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getActivity(), error.toString(),Toast.LENGTH_LONG).show();
                    }
                }
        );


    }

    public void  FinalApproval(String StaffIDNO,String Leave,String strStartdate,String strLastDate,String strDateExpected,String chkRequireLeaveAllowance,String txtDaysApplied,String GetCurrentStaffID,String txtComments,String AppNumber) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setReadTimeout(60 * 1000, TimeUnit.MILLISECONDS);
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setClient(new OkClient(okHttpClient));
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.FinalApproval(
                StaffIDNO,
                Leave,
                strStartdate,
                strLastDate,
                strDateExpected,
                chkRequireLeaveAllowance,
                txtDaysApplied,
                GetCurrentStaffID,
                txtComments,
                AppNumber,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            if(output.equals(""))
                            {
                                output = "Leave Approval Successful";
                            }
                            MyalertDialog(output);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getActivity(), error.toString(),Toast.LENGTH_LONG).show();
                    }
                }
        );


    }
    public void MyalertDialog(String msg)
    {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Response")
                .setMessage(msg)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.ok, null).show();


    }
}
