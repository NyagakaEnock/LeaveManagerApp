package activity;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.SyncStateContract;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;
import com.readystatesoftware.viewbadger.BadgeView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.jar.JarException;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedFile;

/**
 * A simple {@link Fragment} subclass.
 */
public class Dashboard extends Fragment {
    private static ImageView imageView;
    private Resources mResources;
    private Bitmap mBitmap;
    private Button apply,approve,notifications,myprofile;
    private  TextView username,email,staffid;

    public Dashboard() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.dashboard, container, false);
       imageView = (ImageView) rootView.findViewById(R.id.imageView2);

        apply = (Button) rootView.findViewById(R.id.btn_friends);
        approve = (Button) rootView.findViewById(R.id.btn_places);
        notifications = (Button) rootView.findViewById(R.id.btn_places1);
        myprofile = (Button) rootView.findViewById(R.id.btn_news_feed);
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        try
        {
            String jsonResponce = prefs.getString("jsonResponce", null);
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("Notifications");
            if(jresult.length()>0) {
                View target = rootView.findViewById(R.id.btn_places1);
                BadgeView badge = new BadgeView(getActivity(), target);
                badge.setText(jresult.length()+"");
                badge.show();
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }



        username = (TextView) rootView.findViewById(R.id.username);
        email = (TextView) rootView.findViewById(R.id.emailaddress);
        staffid = (TextView) rootView.findViewById(R.id.staffid);
        mResources = getResources();
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, 2);
                Uri selectedImageUri = i.getData();



            }
        });
        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new NewApplication();
                if (fragment != null) {
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Leave Application");
                }
            }
        });
        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Approve();
                if (fragment != null) {
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Leave Approval");
                }
            }
        });
        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Notifications();
                if (fragment != null) {
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Notifications");
                }
            }
        });
        myprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Profile();
                if (fragment != null) {
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("My Profile");
                }
            }
        });

        try
        {
            GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
            String jsonResponce = prefs.getString("jsonResponce", null);
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("result");
            JSONObject object = jresult.getJSONObject(jresult.length() - 1);
            String EmployeeName = "Welcome "+object.getString("AllNames");
            username.setText(EmployeeName);
            email.setText(object.getString("ContEmail"));
            staffid.setText("Staff ID No "+object.getString("StaffIDNO"));
            String path = globalRecordFetch.ROOT_URL+"/uploads/" + object.getString("Photo");
            String NoImagepath = globalRecordFetch.ROOT_URL+"/uploads/" + "noImage.png";
            if(object.getString("Photo").equals("")||object.getString("Photo").equals("null"))
            {
                new DownLoadImageTask(imageView).execute(NoImagepath);
            }else {
                new DownLoadImageTask(imageView).execute(path);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
        return rootView;
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if ( resultCode == Activity.RESULT_OK) {
            String path = getPathFromCameraData(data, this.getActivity());
            if (path != null) {

                TypedFile file = new TypedFile("multipart/form-data", new File(path));
                SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                final String StaffIDNO = prefs.getString("StaffIDNO", "");
                UploadFile(file,StaffIDNO);
            }
        }
    }

    public static String getPathFromCameraData(Intent data, Context context) {
        Uri selectedImage = data.getData();
        String[] filePathColumn = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(selectedImage,
                filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();
        return picturePath;
    }

    public void UploadFile(final TypedFile file,String StaffId) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.UploadFile(
                file,
                StaffId,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();

                                Toast.makeText(getActivity(), Html.fromHtml(output),Toast.LENGTH_LONG).show();


                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        MyalertDialog( error.toString());
                    }
                }
        );


    }
    public void MyalertDialog(String msg)
    {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Response")
                .setMessage(msg)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.ok, null).show();


    }
    public  RoundedBitmapDrawable createRoundedBitmapDrawableWithBorder(Bitmap bitmap){
        RoundedBitmapDrawable roundedBitmapDrawable = null;
        try {
            int bitmapWidth = bitmap.getWidth();
            int bitmapHeight = bitmap.getHeight();
            int borderWidthHalf = 10; // In pixels
            int bitmapRadius = Math.min(bitmapWidth, bitmapHeight) / 2;
            int bitmapSquareWidth = Math.min(bitmapWidth, bitmapHeight);
            int newBitmapSquareWidth = bitmapSquareWidth + borderWidthHalf;
            Bitmap roundedBitmap = Bitmap.createBitmap(newBitmapSquareWidth, newBitmapSquareWidth, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(roundedBitmap);
            canvas.drawColor(Color.parseColor("#1DA1F2"));
            int x = borderWidthHalf + bitmapSquareWidth - bitmapWidth;
            int y = borderWidthHalf + bitmapSquareWidth - bitmapHeight;
            canvas.drawBitmap(bitmap, x, y, null);
            Paint borderPaint = new Paint();
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(borderWidthHalf * 2);
            borderPaint.setColor(Color.parseColor("#F50057"));
            canvas.drawCircle(canvas.getWidth() / 2, canvas.getWidth() / 2, newBitmapSquareWidth / 2, borderPaint);
            roundedBitmapDrawable = RoundedBitmapDrawableFactory.create(mResources, roundedBitmap);
            roundedBitmapDrawable.setCornerRadius(bitmapRadius);
            roundedBitmapDrawable.setAntiAlias(true);

        }catch (NullPointerException e)
        {
            e.printStackTrace();
        }
        return roundedBitmapDrawable;
    }
    public class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {


        public DownLoadImageTask(ImageView imageView) {
            Dashboard.imageView = imageView;
        }

        /*
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String... urls) {
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try {
                InputStream is = new URL(urlOfImage).openStream();
               // logo = BitmapFactory.decodeStream(is);

                BitmapFactory.Options options = new BitmapFactory.Options();


                options.inSampleSize = calculateInSampleSize(options, 100, 100);

                // Decode bitmap with inSampleSize set
                options.inJustDecodeBounds = false;
                logo = BitmapFactory.decodeStream(is, null, options);

            } catch (Exception e) { // Catch the download exception
                e.printStackTrace();
            }

            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result) {


            // mBitmap = BitmapFactory.decodeResource(mResources,R.drawable.boy);
            mBitmap = result;
            RoundedBitmapDrawable drawable = createRoundedBitmapDrawableWithBorder(mBitmap);

            // imageView.setImageBitmap(result);
            // Set the ImageView image as drawable object
            imageView.setImageDrawable(drawable);
        }

    }
    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

}
