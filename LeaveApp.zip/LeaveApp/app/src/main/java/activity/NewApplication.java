package activity;


import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.squareup.okhttp.OkHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.OkClient;
import retrofit.client.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class NewApplication extends Fragment {
private TextView txtPhysicalAddress,Entitlement,BFwd,EarnedToDate,Current,TakenToDate,Balance,NoofDays,weekends,DLastDate,DExpected ;

    private  TextView txtRemarks;
    private TextView txtStartDate;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private Button btnApply;
    private  TextView days,moredetails;

    private Spinner spinner1;
    private static ObjectMapper mapper = new ObjectMapper();
    public NewApplication() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_new_application, container, false);
        txtRemarks = (TextView)rootView.findViewById(R.id.txtRemarks);
        spinner1 = (Spinner) rootView.findViewById(R.id.spinner);
        txtStartDate = (TextView)rootView.findViewById(R.id.txtStartDate);
        btnApply =(Button)rootView.findViewById(R.id.btnApply);
        days = (TextView)rootView.findViewById(R.id.days);
        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validateInput()==true) {
                    SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                    String StaffIDNO = prefs.getString("StaffIDNO", "");
                    GetCurrentLeaveInfo(StaffIDNO,spinner1.getSelectedItem().toString());
                }
            }
        });

        txtStartDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus==true)
                {
                    getDate();
                }

            }
        });
        loadData();

        return rootView;
    }
    public  void loadData()
    {
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("result");
            JSONObject object = jresult.getJSONObject(jresult.length() - 1);
            JSONArray LeaveArray = jsonObject.getJSONArray("LeaveResult");
            List<String> leaveTypes =  new ArrayList<String>();
            leaveTypes.add("Select Leave");
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, leaveTypes);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner1.setAdapter(adapter);
            spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());

            for(int i=0;i<=LeaveArray.length()-1;i++)
            {
                JSONObject NewLeaveObject = LeaveArray.getJSONObject(i);
                leaveTypes.add(NewLeaveObject.getString("Descriptions"));
            }
        }catch (JSONException ex){
            ex.printStackTrace();
        }
    }
    public void getDate()
    {

        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // Launch Date Picker Dialog
        DatePickerDialog dpd = new DatePickerDialog(getActivity(),
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        txtStartDate.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
                        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                        String formattedDate = df.format(c.getTime());
                        ConfirmLeaveApplication confirm = new ConfirmLeaveApplication();
                        if(confirm.daysBetween(confirm.stringToDate(formattedDate.toString(),"yyyy-MM-dd"),confirm.stringToDate(txtStartDate.getText().toString(),"yyyy-MM-dd"))<=0)
                            {
                            Toast.makeText(getActivity(),"Please Select a Future Date",Toast.LENGTH_LONG).show();
                            txtStartDate.setText("");

                        }
                    }
                }, mYear, mMonth, mDay);
        dpd.show();

    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        String firstItem = String.valueOf(spinner1.getSelectedItem());

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            if (firstItem.equals(String.valueOf(spinner1.getSelectedItem()))) {
                // ToDo when first item is selected
            } else {

            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> arg) {

        }

    }

    public  boolean validateInput()
    {
        Boolean State=false;
        if(spinner1.getSelectedItem().equals("Select Leave")){
            Toast.makeText(getActivity(),"Please Select Leave Type",Toast.LENGTH_LONG).show();
            State=false;
        }else if (days.length()==0){
            Toast.makeText(getActivity(),"Enter Number of Days",Toast.LENGTH_LONG).show();
            State=false;
        }else if (txtStartDate.length()==0){
            Toast.makeText(getActivity(),"Select Start Date",Toast.LENGTH_LONG).show();
            State=false;
        }else{
            State = true;
        }
        return State;
    }

    public void showDialog(String EntitlementVal,String LeaveBfwd,String LeaveEarned,String LeaveTaken,String CurrentLeave) {
        ConfirmLeaveApplication confirm = new ConfirmLeaveApplication();
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.more_leave_application_details, null);
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(c.getTime());
        TextView DDateApplied = (TextView) dialogView.findViewById(R.id.DDateApplied);
        DLastDate = (TextView) dialogView.findViewById(R.id.DLastDate);
        TextView DStartDate = (TextView) dialogView.findViewById(R.id.DStartDate);
         DExpected = (TextView) dialogView.findViewById(R.id.DExpected);
         Entitlement = (TextView)dialogView.findViewById(R.id.Entitlement);
         BFwd = (TextView)dialogView.findViewById(R.id.BFwd);
         EarnedToDate = (TextView)dialogView.findViewById(R.id.EarnedToDate);
         Current = (TextView)dialogView.findViewById(R.id.Current);
         TakenToDate = (TextView)dialogView.findViewById(R.id.TakenToDate);
         Balance = (TextView)dialogView.findViewById(R.id.Balance);
        NoofDays = (TextView)dialogView.findViewById(R.id.noofDays);
        weekends = (TextView)dialogView.findViewById(R.id.weekends);

        DDateApplied.setText(formattedDate);
        DStartDate.setText(txtStartDate.getText());
        String dt = txtStartDate.getText().toString();
        Entitlement.setText(EntitlementVal);
        if(EntitlementVal==null||EntitlementVal.equals("")||EntitlementVal.equals("null"))
        {
            EntitlementVal="0.0";
        }
        if(LeaveBfwd==null||LeaveBfwd.equals("")||LeaveBfwd.equals("null"))
        {
            LeaveBfwd="0.0";
        }
        if(LeaveTaken==null||LeaveTaken.equals("")||LeaveTaken.equals("null"))
        {
            LeaveTaken="0.0";
        }

        double result = Double.parseDouble(EntitlementVal)+Double.parseDouble(LeaveBfwd);

        Current.setText(result+"");
        TakenToDate.setText(LeaveTaken);
        EarnedToDate.setText(LeaveEarned);
        BFwd.setText(LeaveBfwd);
        double result2 = result-Double.parseDouble(LeaveTaken);
        Balance.setText(result2+"");
        NoofDays.setText(days.getText().toString());
        String dateInString = dt;  // Start date
        final int noofdays = Integer.parseInt(days.getText().toString());
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        String holiday,CurrentYear,HolidayMonth;
        try {
            c.setTime(df.parse(dateInString));
            c.add(Calendar.DATE, noofdays-1);
            Date resultdate = new Date(c.getTimeInMillis());
            String LastDate = df.format(resultdate);

            int weekendfound =  getWorkingDaysBetweenTwoDates(confirm.stringToDate(dt,"yyyy-MM-dd"), confirm.stringToDate(LastDate,"yyyy-MM-dd"));
            try {
               JSONObject jsonObject = new JSONObject(jsonResponce);
                JSONArray jresult = jsonObject.getJSONArray("ParamHoliday");
                if(jresult.length()>0) {
                    int counter=0;
                    for(int i=0;i<=jresult.length()-1;i++) {

                        JSONObject object = jresult.getJSONObject(i);
                        holiday = object.getString("HolidayDate");
                        HolidayMonth = object.getString("HolidayMonth");
                        CurrentYear = object.getString("CurrentYear");
                        String holidayDate = CurrentYear+"-"+HolidayMonth+"-"+holiday;
                        Date min =confirm.stringToDate(txtStartDate.getText().toString(),"yyyy-MM-dd");
                        Date max =confirm.stringToDate(dateInString,"yyyy-MM-dd");
                        Date a = confirm.stringToDate(holidayDate,"yyyy-MM-dd");
                       if(a.after(min) && a.before(max)) {
                           counter = counter + 1;
                       }
                    }


                }
            }catch (JSONException e){
                e.printStackTrace();
            }

            int newnoofdays=noofdays + weekendfound;
            weekends.setText(weekendfound+"");
            String dateInString2 = txtStartDate.getText().toString();
            c.setTime(df.parse(dateInString2));
            c.add(Calendar.DATE, newnoofdays-1);
            Date resultdate2 = new Date(c.getTimeInMillis());
            dateInString2 = df.format(resultdate2);
            DLastDate.setText( dateInString2);


            //Check if Expected Date falls under Sartuday or Sunday
            Calendar startCal = Calendar.getInstance();
            startCal.setTime(confirm.stringToDate(df.format(resultdate2),"yyyy-MM-dd"));

            if(startCal.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY)
            {
                startCal.setTime(df.parse(dateInString2));
                startCal.add(Calendar.DATE, 2);

            }else if(startCal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)
            {
                startCal.setTime(df.parse(dateInString2));
                startCal.add(Calendar.DATE, 1);

            }else if(startCal.get(Calendar.DAY_OF_WEEK)==Calendar.FRIDAY)
            {
                startCal.setTime(df.parse(dateInString2));
                startCal.add(Calendar.DATE, 3);

            }else{
                startCal.setTime(df.parse(dateInString2));
                startCal.add(Calendar.DATE, 1);

            }
            Date Expected = new Date(startCal.getTimeInMillis());
            String ExpectedDateInString = df.format(Expected);
            DExpected.setText(ExpectedDateInString);
        }catch (ParseException e)
        {
            e.printStackTrace();
        }
        dialogBuilder.setTitle("Leave Application Details");
        dialogBuilder.setPositiveButton("Apply Leave", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int whichButton) {

                AlertDialog.Builder builder =
                        new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                final  String Leave = spinner1.getSelectedItem().toString();
                SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                final String StaffIDNO = prefs.getString("StaffIDNO", "");
                final String strStartdate = txtStartDate.getText().toString();
                final String strLastDate = DLastDate.getText().toString();
                final String strDateExpected = DExpected.getText().toString();
                final String txtDaysApplied = NoofDays.getText().toString();
                final String LeaveBFwd =BFwd.getText().toString();
                final String chkRequireLeaveAllowance ="0";
                final String txtComments = txtRemarks.getText().toString();
                builder.setTitle("Confirmation Required")
                        .setMessage("Are you Sure you want to apply for "+spinner1.getSelectedItem().toString()+"?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                NewApplication(StaffIDNO,Leave,strStartdate,strLastDate,strDateExpected,txtDaysApplied,LeaveBFwd,chkRequireLeaveAllowance,txtComments);
                            }})
                        .setNegativeButton(android.R.string.no, null).show();

            }});

        dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int whichButton) {
               dialog.cancel();
            }});
        dialogBuilder.setView(dialogView);
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

    }

    public void MyalertDialog(String msg)
    {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Response")
                .setMessage(msg)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.ok, null).show();


    }
    public static int getWorkingDaysBetweenTwoDates(Date startDate, Date endDate) {
        Calendar startCal = Calendar.getInstance();
        startCal.setTime(startDate);
        Calendar endCal = Calendar.getInstance();
        endCal.setTime(endDate);
        int workDays = 0;
        //Return 0 if start and end are the same
        if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
            return 0;
        }
        if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
            startCal.setTime(endDate);
            endCal.setTime(startDate);
        }

        do {
            //excluding start date
            startCal.add(Calendar.DAY_OF_MONTH, 1);
            if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||startCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                ++workDays;
            }

        } while (startCal.getTimeInMillis() <= endCal.getTimeInMillis()); //excluding end date

        return workDays;
    }

    public static String filterJsonArray(String array, String keyOne, Object valueOne, String keyTwo, Object valueTwo) throws IOException {

        Map[] nodes = mapper.readValue(array, HashMap[].class);

        for (Map node : nodes) {
            if (node.containsKey(keyOne) && node.containsKey(keyTwo)) {
                if (node.get(keyOne).equals(valueOne) && node.get(keyTwo).equals(valueTwo)) {
                    return mapper.writeValueAsString(node);
                }
            }
        }

        return null;
    }
    public void GetCurrentLeaveInfo(final String StaffId, String Leave) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.GetCurrentLeaveInfo(
                StaffId,
                Leave,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();

                            SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                            try {
                                JSONObject jsonObject = new JSONObject(output);
                                JSONArray jresult = jsonObject.getJSONArray("GetCurrentLeaveInfo");
                                JSONObject object = jresult.getJSONObject(jresult.length() - 1);
                                String LeaveEntitlement = object.getString("LeaveEntitlement");
                                String LeaveBfwd = object.getString("LeaveBfwd");
                                String LeaveEarned = object.getString("LeaveEarned");
                                String LeaveTaken = object.getString("LeaveTaken");
                                String CurrentLeave = object.getString("CurrentLeave");
                                showDialog(LeaveEntitlement,LeaveBfwd,LeaveEarned,LeaveTaken,CurrentLeave);
                            }catch (JSONException e){
                                e.printStackTrace();
                            }


                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getActivity(), "Connection Failed. Please Try Again.",Toast.LENGTH_LONG).show();
                    }
                }
        );


    }

    public void NewApplication(final String StaffId, String Leave,String strStartdate,String strLastDate,String strDateExpected,String txtDaysApplied,String LeaveBFwd,String chkRequireLeaveAllowance,String txtComments) {
        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setReadTimeout(120 * 1000, TimeUnit.MILLISECONDS);
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setClient(new OkClient(okHttpClient));
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.NewApplication(
                StaffId,
                Leave,
                strStartdate,
                strLastDate,
                strDateExpected,
                txtDaysApplied,
                LeaveBFwd,
                chkRequireLeaveAllowance,
                txtComments,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            if(output.equals(""))
                            {
                                output = "Leave Application Successful";
                            }
                            MyalertDialog(output);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getActivity(), error.toString(),Toast.LENGTH_LONG).show();
                    }
                }
        );


    }
}
