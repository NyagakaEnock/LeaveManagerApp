package activity;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import adapter.ExpandableListAdapter;
import adapter.MoviesAdapter;
import model.Movie;
import model.RefreshApp;

/**
 * A simple {@link Fragment} subclass.
 */
public class Approve extends Fragment {
    private List<Movie> movieList = new ArrayList<>();
    private RecyclerView recyclerView;
    private MoviesAdapter mAdapter;
    private TextView approvalLevel;
    private int itemsCounter;
    public Approve() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.content_main, container, false);
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String StaffId = prefs.getString("StaffIDNO", null);
        new RefreshApp(getActivity()).execute(StaffId);
       recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);
        approvalLevel = (TextView)rootView.findViewById(R.id.approvalLevel);
        mAdapter = new MoviesAdapter(movieList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);

        int i =  prepareMovieData();
        int j =  prepareSecondApproval();
        int k = prepareFinalApproval();
        if(i>0)
        {
                itemsCounter=1;
        }else if(j>0)
        {
            itemsCounter=2;
        }else if(k>0)
        {
            itemsCounter=3;
        }else
        {
            itemsCounter=0;
        }
        recyclerView.addOnItemTouchListener(new FragmentDrawer.RecyclerTouchListener(getActivity(), recyclerView, new FragmentDrawer.ClickListener() {
            @Override
            public void onClick(View view, int position) {

                Movie movie = movieList.get(position);
                Fragment fragment = null;
                fragment =  new ConfirmLeaveApplication();
                if (fragment != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString("LeaveApplicationDetails",movie.getJsonObject().toString());
                    bundle.putInt("itemsCounter",itemsCounter);
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container_body, fragment);
                    fragmentTransaction.commit();
                    ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Confirm Leave Application");
                }

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        return rootView;
    }

    private int prepareMovieData() {
        int counter = 0;
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("LeaveApplicationResult");
            counter= jresult.length();

            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String EmployeeName = LeaveApplicationObject.getString("AllNames");
                String LeaveType = LeaveApplicationObject.getString("Descriptions");
                String DateApplied =  LeaveApplicationObject.getString("DateApplied").substring(0,10);

                String Period = "From "+LeaveApplicationObject.getString("StartDate").substring(0,10)+" to "+LeaveApplicationObject.getString("LastDate").substring(0,10)+" ("+LeaveApplicationObject.getString("DaysApplied").substring(0,2)+" Days)";
                Movie movie = new Movie(EmployeeName, LeaveType, DateApplied, Period,LeaveApplicationObject);
                movieList.add(movie);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
return  counter;
    }
    private int prepareSecondApproval() {
        int counter = 0;
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("PendingSecondApproval");
            counter =jresult.length();
            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String EmployeeName = LeaveApplicationObject.getString("AllNames");
                String LeaveType = LeaveApplicationObject.getString("Descriptions");
                String DateApplied =  LeaveApplicationObject.getString("DateApplied").substring(0,10);

                String Period = "From "+LeaveApplicationObject.getString("StartDate").substring(0,10)+" to "+LeaveApplicationObject.getString("LastDate").substring(0,10)+" ("+LeaveApplicationObject.getString("DaysApplied").substring(0,2)+" Days)";
                Movie movie = new Movie(EmployeeName, LeaveType, DateApplied, Period,LeaveApplicationObject);
                movieList.add(movie);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
        return  counter;
    }
    private int prepareFinalApproval() {
        int counter = 0;
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        String jsonResponce = prefs.getString("jsonResponce", null);
        try {
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("PendingThirdApproval");
            counter =jresult.length();
            for(int i=0;i<=jresult.length()-1;i++)
            {
                JSONObject LeaveApplicationObject = jresult.getJSONObject(i);
                String EmployeeName = LeaveApplicationObject.getString("AllNames");
                String LeaveType = LeaveApplicationObject.getString("Descriptions");
                String DateApplied =  LeaveApplicationObject.getString("DateApplied").substring(0,10);

                String Period = "From "+LeaveApplicationObject.getString("StartDate").substring(0,10)+" to "+LeaveApplicationObject.getString("LastDate").substring(0,10)+" ("+LeaveApplicationObject.getString("DaysApplied").substring(0,2)+" Days)";
                Movie movie = new Movie(EmployeeName, LeaveType, DateApplied, Period,LeaveApplicationObject);
                movieList.add(movie);
            }
        }catch (JSONException e)
        {
            e.printStackTrace();
        }

        mAdapter.notifyDataSetChanged();
        return  counter;
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerItemListner implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private Approve.ClickListener clickListener;

        public RecyclerItemListner(Context context, final RecyclerView recyclerView, final Approve.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {

                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}
