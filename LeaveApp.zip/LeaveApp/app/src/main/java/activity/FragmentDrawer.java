package activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.support.v7.widget.RecyclerView;
import com.example.enock.retrofit.R;
import android.support.v7.widget.Toolbar;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.view.GestureDetector;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import adapter.MyAdapter;
import adapter.NavigationDrawerAdapter;
import adapter.SimpleDividerItemDecoration;
import model.ApiClient;
import model.Employee;
import model.EmployeeAPI;
import model.GlobalRecordFetch;
import model.ItemsData;
import model.NavDrawerItem;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

import android.os.AsyncTask;

public class FragmentDrawer extends Fragment implements View.OnClickListener{
    private static String TAG = FragmentDrawer.class.getSimpleName();
    public static final String ROOT_URL = "http://jobspot.co.ke";
    private RecyclerView recyclerView;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private NavigationDrawerAdapter adapter;
    private View containerView;
    private static String[] titles = null;
    private FragmentDrawerListener drawerListener;
    private Context context;
    private String jsonResponce;
    private String output;
    private TextView usertextView;
    private static ImageView imageView;
    private Resources mResources;
    private Bitmap mBitmap;

    public String responce;
    public FragmentDrawer() {

    }
public void onClick(View view)
{

}
    public void setDrawerListener(FragmentDrawerListener listener) {
        this.drawerListener = listener;
    }

    public static List<NavDrawerItem> getData() {
        List<NavDrawerItem> data = new ArrayList<>();


        // preparing navigation drawer items
        for (int i = 0; i < titles.length; i++) {
            NavDrawerItem navItem = new NavDrawerItem();
            navItem.setTitle(titles[i]);
            data.add(navItem);
        }
        return data;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // drawer labels
        titles = getActivity().getResources().getStringArray(R.array.nav_drawer_labels);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflating view layout
        View layout = inflater.inflate(R.layout.fragment_navigation_drawer, container, false);
        recyclerView = (RecyclerView) layout.findViewById(R.id.drawerList);
        usertextView = (TextView) layout.findViewById(R.id.user);
        imageView = (ImageView) layout.findViewById(R.id.imageView);
      //  adapter = new NavigationDrawerAdapter(getActivity(), getData());
        ItemsData itemsData[] = { new ItemsData("Home",R.drawable.home),
                new ItemsData("My Profile",R.drawable.boy),
                new ItemsData("Apply For Leave",R.drawable.schedule2),
                new ItemsData("My Leave History",R.drawable.apply),
                new ItemsData("Leave Approval",R.drawable.success),
                new ItemsData("Notifications",R.drawable.bell
               )};
        // 2. set layoutManger
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        // 3. create an adapter
        MyAdapter mAdapter = new MyAdapter(itemsData);
        // 4. set adapter
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                drawerListener.onDrawerItemSelected(view, position);
                mDrawerLayout.closeDrawer(containerView);
            }
            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
        try {
            String jsonResponce = prefs.getString("jsonResponce", null);
            JSONObject jsonObject = new JSONObject(jsonResponce);
            JSONArray jresult = jsonObject.getJSONArray("result");
            JSONObject object = jresult.getJSONObject(jresult.length() - 1);
            String EmployeeName = "Welcome "+object.getString("AllNames");
            usertextView.setText(EmployeeName);
            GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
            String path = globalRecordFetch.ROOT_URL+"/uploads/" + object.getString("Photo");
            String NoImagepath = globalRecordFetch.ROOT_URL+"/uploads/" + "noImage.png";
            SharedPreferences.Editor editor = getActivity().getSharedPreferences("MySessions", 0).edit();
            editor.putString("StaffIDNO",object.getString("StaffIDNO"));
            editor.commit();
            mResources = getResources();
            mBitmap = BitmapFactory.decodeResource(mResources, R.drawable.boy);
            RoundedBitmapDrawable drawable = createRoundedBitmapDrawableWithBorder(mBitmap);
            imageView.setImageDrawable(drawable);
            if(object.getString("Photo").equals("")||object.getString("Photo").equals("null")) {
                try
                {
                    new DownLoadImageTask(imageView).execute(NoImagepath);
                }catch (NullPointerException e)
                {
                    e.printStackTrace();
                }


                // Set the ImageView image as drawable object

            }else{
                new DownLoadImageTask(imageView).execute(path);
            }
        }catch (JSONException e){
            e.printStackTrace();
        }

        return layout;
    }


    public void setUp(int fragmentId, DrawerLayout drawerLayout, final Toolbar toolbar) {
        containerView = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawerLayout;
        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                toolbar.setAlpha(1 - slideOffset / 2);
            }
        };

        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

    }

    public static interface ClickListener {
        public void onClick(View view, int position);

        public void onLongClick(View view, int position);
    }

    static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }


    }

    public interface FragmentDrawerListener {
        public void onDrawerItemSelected(View view, int position);
    }



    public class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {


        public DownLoadImageTask(ImageView imageView) {
            FragmentDrawer.imageView = imageView;
        }

        /*
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String... urls) {
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try {
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            } catch (Exception e) { // Catch the download exception
                e.printStackTrace();
            }

            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result) {
            imageView.setImageBitmap(result);
            mBitmap = result;
            RoundedBitmapDrawable drawable = createRoundedBitmapDrawableWithBorder(mBitmap);

            // Set the ImageView image as drawable object
            imageView.setImageDrawable(drawable);
        }

    }

    public  RoundedBitmapDrawable createRoundedBitmapDrawableWithBorder(Bitmap bitmap){
        RoundedBitmapDrawable roundedBitmapDrawable=null;
        try
        {
            int bitmapWidth = bitmap.getWidth();
            int bitmapHeight = bitmap.getHeight();
            int borderWidthHalf = 10; // In pixels
            int bitmapRadius = Math.min(bitmapWidth,bitmapHeight)/2;
            int bitmapSquareWidth = Math.min(bitmapWidth,bitmapHeight);
            int newBitmapSquareWidth = bitmapSquareWidth+borderWidthHalf;
            Bitmap roundedBitmap = Bitmap.createBitmap(newBitmapSquareWidth,newBitmapSquareWidth,Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(roundedBitmap);
            canvas.drawColor(Color.parseColor("#1DA1F2"));
            int x = borderWidthHalf + bitmapSquareWidth - bitmapWidth;
            int y = borderWidthHalf + bitmapSquareWidth - bitmapHeight;
            canvas.drawBitmap(bitmap, x, y, null);
            Paint borderPaint = new Paint();
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(borderWidthHalf*2);
            borderPaint.setColor(Color.parseColor("#FF9933"));
            canvas.drawCircle(canvas.getWidth()/2, canvas.getWidth()/2, newBitmapSquareWidth/2, borderPaint);
            roundedBitmapDrawable = RoundedBitmapDrawableFactory.create(mResources,roundedBitmap);
            roundedBitmapDrawable.setCornerRadius(bitmapRadius);
            roundedBitmapDrawable.setAntiAlias(true);

        }catch (NullPointerException e)
        {
            e.printStackTrace();
        }
        return roundedBitmapDrawable;
    }
}
