package activity;


import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import model.Movie;
import model.NotificationDetails;
import model.RefreshApp;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class ReadNotification extends Fragment {
private TextView subject,message,datesent;
FloatingActionButton deleteNotification;
    public ReadNotification() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_read_notification, container, false);
        subject = (TextView)rootView.findViewById(R.id.NotificationTitle);
        message = (TextView)rootView.findViewById(R.id.NotificationMessage);
        datesent = (TextView)rootView.findViewById(R.id.NotificationDate);
        deleteNotification = (FloatingActionButton)rootView.findViewById(R.id.deleteNotification);
        deleteNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new AlertDialog.Builder(getActivity())
                        .setTitle("Confirm Delete?")
                        .setMessage("Are you sure you want to Delete this Notification?")
                        .setNegativeButton(android.R.string.no, null)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface arg0, int arg1) {
                                try{
                                    SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                                    String jsonResponce = prefs.getString("jsonResponce", null);
                                    JSONObject jsonObject = new JSONObject(jsonResponce);

                                    JSONArray jresult = jsonObject.getJSONArray("Notifications");
                                    JSONObject LeaveApplicationObject = jresult.getJSONObject(0);
                                    final String ID = LeaveApplicationObject.getString("ID");

                                    DeleteNotifications(ID);
                                }catch (JSONException e){
                                    e.printStackTrace();
                                }
                            }
                        }).create().show();
            }
        });
        getData();
        return rootView;
    }
    void DeleteNotifications(String Id) {
        RestAdapter.Builder builder = new RestAdapter.Builder();
        GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.DeleteNotifications(
                Id,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();
                            Toast.makeText(getActivity(), output,Toast.LENGTH_LONG).show();
                            SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                            final String StaffIDNO = prefs.getString("StaffIDNO", "");
                            new RefreshApp(getActivity()).execute(StaffIDNO);
                            Fragment fragment = new Notifications();
                            if (fragment != null) {
                                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                fragmentTransaction.replace(R.id.container_body, fragment);
                                fragmentTransaction.commit();
                                ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Notifications");
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void failure(RetrofitError error) {
                        Toast.makeText(getActivity(), "Connection Failed. Please Try Again.",Toast.LENGTH_LONG).show();
                    }
                }
        );

    }
    private void getData()
    {
        String NotificationDetails = getArguments().getString("NotificationDetails","NULL");
        try{
            JSONObject jsonObject = new JSONObject(NotificationDetails);
            subject.setText(Html.fromHtml(jsonObject.getString("Subject")));
            message.setText(Html.fromHtml(jsonObject.getString("Message")));
            datesent.setText("Date Sent :"+jsonObject.getString("DateCreated"));

        }catch (JSONException e){
            e.printStackTrace();
        }
    }
}
