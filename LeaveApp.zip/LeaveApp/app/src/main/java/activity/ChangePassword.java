package activity;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.enock.retrofit.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import model.EmployeeAPI;
import model.GlobalRecordFetch;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class ChangePassword extends Fragment {
private TextView password,NewPassword,Confirm;
    private Button changePassword;

    public ChangePassword() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_change_password, container, false);
        password = (TextView)rootView.findViewById(R.id.Password);
        NewPassword = (TextView)rootView.findViewById(R.id.NewPassword);
        Confirm = (TextView)rootView.findViewById(R.id.Confirm);
        changePassword = (Button) rootView.findViewById(R.id.changePassword);
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validatePass()==true)
                {
                    SharedPreferences prefs = getActivity().getSharedPreferences("MySessions", 0);
                    final String StaffIDNO = prefs.getString("StaffIDNO", "");
                    ChangePass(password.getText().toString(),NewPassword.getText().toString(),Confirm.getText().toString(),StaffIDNO);
                }

            }
        });
        return rootView;
    }

    private boolean validatePass()
    {
        if(password.length()==0)
        {
            Toast.makeText(getActivity(),"Enter Current Password",Toast.LENGTH_LONG).show();
            return false;
        }else if(NewPassword.length()==0)
        {
            Toast.makeText(getActivity(),"Enter New Password",Toast.LENGTH_LONG).show();
            return false;
        }else if(Confirm.length()==0)
        {
            Toast.makeText(getActivity(),"Confirm New Password",Toast.LENGTH_LONG).show();
            return false;
        }else if(!Confirm.getText().toString().equals(NewPassword.getText().toString()))
        {
            Toast.makeText(getActivity(),"Your Password do not Match",Toast.LENGTH_LONG).show();
            return false;
        }else
        {
            return  true;
        }
    }

    public void ChangePass(final String current, String password,String Confirm,String StaffIDNo) {

        final ProgressDialog loading = ProgressDialog.show(getActivity(), "", "Please wait...", false, false);
        RestAdapter.Builder builder = new RestAdapter.Builder();
        final GlobalRecordFetch globalRecordFetch = new GlobalRecordFetch(getActivity());
        builder.setEndpoint(globalRecordFetch.ROOT_URL);
        builder.setLogLevel(RestAdapter.LogLevel.FULL);
        RestAdapter restAdapter = builder.build();
        EmployeeAPI api = restAdapter.create(EmployeeAPI.class);
        api.ChangePass(
                current,
                Confirm,
                StaffIDNo,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        String output = "";
                        try {
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            output = reader.readLine();

                            globalRecordFetch.MyalertDialog(output);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        loading.dismiss();
                    }
                    @Override
                    public void failure(RetrofitError error) {
                        loading.dismiss();
                        Toast.makeText(getActivity(), "Try again "+error.toString(),Toast.LENGTH_LONG).show();
                    }
                }
        );


    }
}
